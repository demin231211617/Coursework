--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8
-- Dumped by pg_dump version 14.8

-- Started on 2023-06-06 17:19:12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 210 (class 1259 OID 16924)
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    client_id integer NOT NULL,
    client_fio character varying(150) NOT NULL,
    client_phone character varying(12) NOT NULL,
    client_adress character varying(500) NOT NULL
);


ALTER TABLE public.client OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 16923)
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.client_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_client_id_seq OWNER TO postgres;

--
-- TOC entry 3368 (class 0 OID 0)
-- Dependencies: 209
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.client_client_id_seq OWNED BY public.client.client_id;


--
-- TOC entry 216 (class 1259 OID 17010)
-- Name: employee_db; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_db (
    employee_id integer NOT NULL,
    employee_fio character varying(150) NOT NULL,
    serial_number character varying(10) DEFAULT 'xxxxx xxxxx'::character varying NOT NULL,
    date_of_issue date NOT NULL,
    division_code character varying(7) DEFAULT '666-666'::character varying NOT NULL,
    employee_phone character varying(12) DEFAULT '+7(999)999-99-99'::character varying NOT NULL,
    employee_adress character varying(500) NOT NULL,
    employee_job_title character varying(50) NOT NULL,
    employee_wage integer NOT NULL,
    login character varying(50) DEFAULT 'xxxxxx.xxx@gmail.com'::character varying NOT NULL,
    password_employee character varying(50) NOT NULL,
    serial_employee character varying(4) NOT NULL
);


ALTER TABLE public.employee_db OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 17009)
-- Name: employee_db_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_db_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_db_employee_id_seq OWNER TO postgres;

--
-- TOC entry 3369 (class 0 OID 0)
-- Dependencies: 215
-- Name: employee_db_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_db_employee_id_seq OWNED BY public.employee_db.employee_id;


--
-- TOC entry 214 (class 1259 OID 16949)
-- Name: job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job (
    job_id integer NOT NULL,
    title_job character varying(50) NOT NULL,
    job_description character varying(500) NOT NULL
);


ALTER TABLE public.job OWNER TO postgres;

--
-- TOC entry 213 (class 1259 OID 16948)
-- Name: job_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.job_job_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_job_id_seq OWNER TO postgres;

--
-- TOC entry 3370 (class 0 OID 0)
-- Dependencies: 213
-- Name: job_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.job_job_id_seq OWNED BY public.job.job_id;


--
-- TOC entry 212 (class 1259 OID 16935)
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    suppliers_id integer NOT NULL,
    suppliers_title character varying(500) NOT NULL,
    suppliers_adress character varying(500) NOT NULL,
    suppliers_phone character varying(12) DEFAULT '+7(999)999-99-99'::character varying NOT NULL
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- TOC entry 211 (class 1259 OID 16934)
-- Name: suppliers_suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suppliers_suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suppliers_suppliers_id_seq OWNER TO postgres;

--
-- TOC entry 3371 (class 0 OID 0)
-- Dependencies: 211
-- Name: suppliers_suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suppliers_suppliers_id_seq OWNED BY public.suppliers.suppliers_id;


--
-- TOC entry 3179 (class 2604 OID 16927)
-- Name: client client_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client ALTER COLUMN client_id SET DEFAULT nextval('public.client_client_id_seq'::regclass);


--
-- TOC entry 3183 (class 2604 OID 17013)
-- Name: employee_db employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db ALTER COLUMN employee_id SET DEFAULT nextval('public.employee_db_employee_id_seq'::regclass);


--
-- TOC entry 3182 (class 2604 OID 16952)
-- Name: job job_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job ALTER COLUMN job_id SET DEFAULT nextval('public.job_job_id_seq'::regclass);


--
-- TOC entry 3180 (class 2604 OID 16938)
-- Name: suppliers suppliers_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN suppliers_id SET DEFAULT nextval('public.suppliers_suppliers_id_seq'::regclass);


--
-- TOC entry 3356 (class 0 OID 16924)
-- Dependencies: 210
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (client_id, client_fio, client_phone, client_adress) FROM stdin;
1	Дмитрий Васильевич	+7896541235	г.Екатеринбург, ул. Калинина, д. 56, кв. 23
\.


--
-- TOC entry 3362 (class 0 OID 17010)
-- Dependencies: 216
-- Data for Name: employee_db; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_db (employee_id, employee_fio, serial_number, date_of_issue, division_code, employee_phone, employee_adress, employee_job_title, employee_wage, login, password_employee, serial_employee) FROM stdin;
1	Дёмин Дмитрий Васильевич	7896541236	2023-05-23	666-666	+78965412356	дфопрлфпф	Администратор	250000	digma21	digma21	15F4
\.


--
-- TOC entry 3360 (class 0 OID 16949)
-- Dependencies: 214
-- Data for Name: job; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job (job_id, title_job, job_description) FROM stdin;
1	Администратор	Данный пользователь может всё
\.


--
-- TOC entry 3358 (class 0 OID 16935)
-- Dependencies: 212
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (suppliers_id, suppliers_title, suppliers_adress, suppliers_phone) FROM stdin;
1	WestStyle	г. Екатеринбург, ул. Маминого-Сибиряка, д. 34	+78965412356
\.


--
-- TOC entry 3372 (class 0 OID 0)
-- Dependencies: 209
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_client_id_seq', 16, true);


--
-- TOC entry 3373 (class 0 OID 0)
-- Dependencies: 215
-- Name: employee_db_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_db_employee_id_seq', 1, false);


--
-- TOC entry 3374 (class 0 OID 0)
-- Dependencies: 213
-- Name: job_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.job_job_id_seq', 1, false);


--
-- TOC entry 3375 (class 0 OID 0)
-- Dependencies: 211
-- Name: suppliers_suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_suppliers_id_seq', 2, true);


--
-- TOC entry 3189 (class 2606 OID 16933)
-- Name: client client_client_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_client_phone_key UNIQUE (client_phone);


--
-- TOC entry 3191 (class 2606 OID 16931)
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- TOC entry 3203 (class 2606 OID 17027)
-- Name: employee_db employee_db_employee_job_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_employee_job_title_key UNIQUE (employee_job_title);


--
-- TOC entry 3205 (class 2606 OID 17025)
-- Name: employee_db employee_db_employee_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_employee_phone_key UNIQUE (employee_phone);


--
-- TOC entry 3207 (class 2606 OID 17029)
-- Name: employee_db employee_db_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_login_key UNIQUE (login);


--
-- TOC entry 3209 (class 2606 OID 17031)
-- Name: employee_db employee_db_password_employee_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_password_employee_key UNIQUE (password_employee);


--
-- TOC entry 3211 (class 2606 OID 17021)
-- Name: employee_db employee_db_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 3213 (class 2606 OID 17033)
-- Name: employee_db employee_db_serial_employee_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_serial_employee_key UNIQUE (serial_employee);


--
-- TOC entry 3215 (class 2606 OID 17023)
-- Name: employee_db employee_db_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_db
    ADD CONSTRAINT employee_db_serial_number_key UNIQUE (serial_number);


--
-- TOC entry 3199 (class 2606 OID 16956)
-- Name: job job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (job_id);


--
-- TOC entry 3201 (class 2606 OID 16958)
-- Name: job job_title_job_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_title_job_key UNIQUE (title_job);


--
-- TOC entry 3193 (class 2606 OID 16943)
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (suppliers_id);


--
-- TOC entry 3195 (class 2606 OID 16947)
-- Name: suppliers suppliers_suppliers_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_suppliers_phone_key UNIQUE (suppliers_phone);


--
-- TOC entry 3197 (class 2606 OID 16945)
-- Name: suppliers suppliers_suppliers_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_suppliers_title_key UNIQUE (suppliers_title);


-- Completed on 2023-06-06 17:19:12

--
-- PostgreSQL database dump complete
--

