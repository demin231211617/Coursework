﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.FolderGlassColor;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace thisNumberOne.NewDoor
{
    public class door
    {
        [Key] public int door_id { get; set; }
        public string door_title { get; set; }
        public string door_model { get; set; }
        public int door_cost { get; set; }
        public int number_ofdoors { get; set; }
        public string vendor_code_door { get; set; }
        [ForeignKey("suppliersEntity")]public int door_suplliers { get; set; }
        [ForeignKey("doorColorEnity")]public int door_color_pluse { get; set; }
        [ForeignKey("glassColorEntity")]public int door_glass_pluse { get; set; }
        public door_color doorColorEnity{get; set;}
        public glass_color glassColorEntity { get; set; }
        public suppliers suppliersEntity { get; set; }
        public List<sale> doorEntities { get; set; }
    }
}
