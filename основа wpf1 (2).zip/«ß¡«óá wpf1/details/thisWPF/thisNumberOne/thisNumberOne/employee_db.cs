﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace thisNumberOne
{
    public class employee_db
    {
        [Key] public int employee_id { get; set; }
        public string employee_fio { get; set; }
        public string employee_phone { get; set; }
        public string employee_adress { get; set; }
        public int employee_wage { get; set; }
        public string login { get; set; }
        public string password_employee { get; set; }
        public string serial_employee { get; set; }
        [ForeignKey("jobEntity")]public int employee_job_title { get; set; }
        public job jobEntity { get; set; }
        public List<sale> employeeEntities {  get; set; }
    }
}
