﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewDoor;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для sales.xaml
    /// </summary>
    public partial class sales : Page
    {
        public sales()
        {
            InitializeComponent();
            ewq.ItemsSource = DatabaseControl.GetSaleForView();
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void plus_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new addSale();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            sale p = ewq.SelectedItem as sale;
            if (p != null)
            {
                //ret.Content = new NewDoor.editDoor(p);
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            sale door = ewq.SelectedItem as sale;
            if (door != null)
            {
                DatabaseControl.DelSale(ewq.SelectedItem as sale);
                ewq.ItemsSource = null;
                //ret.Content = new doorProduct();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");
            }
        }
    }
}
