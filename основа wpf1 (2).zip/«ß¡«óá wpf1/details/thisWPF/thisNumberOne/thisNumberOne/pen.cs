﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.FolderPenColor;

namespace thisNumberOne
{
    public class pen
    {
        [Key] public int pen_id { get; set; }
        public string pen_title { get; set; }
        public int pen_cost { get; set; }
        public int number_of_pen { get; set; }
        public int vendor_code_pen { get; set; }
        [ForeignKey("suppliersPenEnity")] public int pen_supplies { get; set; }
        [ForeignKey("penColorEnity")] public int pen_color { get; set; }
        public suppliers suppliersPenEnity { get; set; }
        public color_pen penColorEnity { get; set; }
        public List<sale> penEntities { get; set; }
    }
}
