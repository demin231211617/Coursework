﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne.NewFolder1
{
    /// <summary>
    /// Логика взаимодействия для DoorColor.xaml
    /// </summary>
    public partial class DoorColor : Page
    {
        public DoorColor()
        {
            InitializeComponent();
            doorColor.ItemsSource = DatabaseControl.GetDoorColorForView();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            door_color p = doorColor.SelectedItem as door_color;
            if (p != null)
            {
                ret.Content = new editDoorColor(p);
            }
            else
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            door_color p = doorColor.SelectedItem as door_color;
            if (p != null)
            {
                DatabaseControl.DelDoorColor(doorColor.SelectedItem as door_color);
                doorColor.ItemsSource = null;
                doorColor.ItemsSource = DatabaseControl.GetDoorColorForView();
            }
            else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new addDoorColor();
        }
    }
}
