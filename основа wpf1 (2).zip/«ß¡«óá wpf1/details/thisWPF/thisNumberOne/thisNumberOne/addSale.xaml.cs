﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addSale.xaml
    /// </summary>
    public partial class addSale : Page
    {
        public addSale()
        {
            InitializeComponent();
            dc.ItemsSource = DatabaseControl.GetPhonesForView();
            dg.ItemsSource = DatabaseControl.GetEmployeeList();
            ds.ItemsSource = DatabaseControl.GetDoorForView();
            db.ItemsSource = DatabaseControl.GetPenForView();
            fb.ItemsSource = DatabaseControl.GetPaymentForView();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            sale _tempSale = new sale();
            _tempSale.buyer = (int)dc.SelectedValue;
            _tempSale.saller = (int)dg.SelectedValue;
            _tempSale.sale_door = (int)ds.SelectedValue;
            _tempSale.sale_pen = (int)db.SelectedValue;
            _tempSale.sale_payment = (int)fb.SelectedValue;
            _tempSale.sale_cost = Convert.ToInt32(nameView.Text);
            DatabaseControl.AddSale(new sale
            {
                buyer = (int)dc.SelectedValue,
                saller = (int)dg.SelectedValue,
                sale_door = (int)ds.SelectedValue,
                sale_pen = (int)db.SelectedValue,
                sale_payment = (int)fb.SelectedValue,
                sale_cost = Convert.ToInt32(nameView.Text),
            });
            daf.Content = new sales();
        }
    }
}
