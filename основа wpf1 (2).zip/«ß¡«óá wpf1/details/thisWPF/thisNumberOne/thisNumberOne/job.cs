﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace thisNumberOne
{
    public class job
    {
        [Key] public int job_id { get; set; }
        public string title_job { get; set; }
        public string job_description { get; set; }

        public List<employee_db> employeeEntities { get; set; }
    }
}
