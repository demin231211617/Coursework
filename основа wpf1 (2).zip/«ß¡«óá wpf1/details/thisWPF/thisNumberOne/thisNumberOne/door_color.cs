﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.NewDoor;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace thisNumberOne
{
    public class door_color
    {
        [Key]public int door_color_id { get; set; }
        public string door_color_title { get; set; }
        public List<door> door_colorEntities { get; set; }
    }
}
