﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для editAnClient.xaml
    /// </summary>
    public partial class editAnClient : Page
    {
        public client _tempClient = new client();
        public editAnClient(client client)
        {
            InitializeComponent();
            _tempClient = client;
            fioView.Text = client.client_fio;
            phoneView.Text = client.client_phone;
            adressView.Text = client.client_adress;
        }
        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(customerVerification.CheckEmpty(fioView.Text, phoneView.Text, adressView.Text))
                {
                    _tempClient.client_fio = fioView.Text;
                    _tempClient.client_phone = phoneView.Text;
                    _tempClient.client_adress = adressView.Text;
                }
                DatabaseControl.UpdateClient(_tempClient);
                gaf.Content = new User();
            }
            catch
            {
                MessageBox.Show("Ошибка данных при вводе", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
