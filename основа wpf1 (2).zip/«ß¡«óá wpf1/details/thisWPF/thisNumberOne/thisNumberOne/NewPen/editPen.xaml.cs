﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewDoor;

namespace thisNumberOne.NewPen
{
    /// <summary>
    /// Логика взаимодействия для editPen.xaml
    /// </summary>
    public partial class editPen : Page
    {
        public pen _tempPen = new pen();
        public editPen(pen pen)
        {
            InitializeComponent();
            pc.ItemsSource = DatabaseControl.GetPenColorForView();
            ps.ItemsSource = DatabaseControl.GetSuppliersForView();

            _tempPen = pen;
            nameView.Text = pen.pen_title;
            numberView.Text = pen.number_of_pen.ToString();
            costView.Text = pen.pen_cost.ToString();
            venderView.Text = pen.vendor_code_pen.ToString();
            pc.SelectedValue = pen.pen_color;
            ps.SelectedValue = pen.pen_supplies;
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _tempPen.pen_title = nameView.Text;
            _tempPen.number_of_pen = Convert.ToInt32(numberView.Text);
            _tempPen.pen_cost = Convert.ToInt32(costView.Text);
            _tempPen.vendor_code_pen = Convert.ToInt32(venderView.Text);
            _tempPen.pen_color = (int)pc.SelectedValue;
            _tempPen.pen_supplies = (int)ps.SelectedValue;
            DatabaseControl.UpdatePen(_tempPen);
            daf.Content = new PenProduct();
        }
    }
}
