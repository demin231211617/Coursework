﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewFolder1;

namespace thisNumberOne.FolderPenColor
{
    /// <summary>
    /// Логика взаимодействия для editPenColor.xaml
    /// </summary>
    public partial class editPenColor : Page
    {
        public color_pen _pen_color = new color_pen();
        public editPenColor(color_pen pen_color)
        {
            InitializeComponent();
            _pen_color = pen_color;
            fioView.Text = _pen_color.pen_color_title;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _pen_color.pen_color_title = fioView.Text;
            DatabaseControl.UpdatePenColor(_pen_color);
            gaf.Content = new penColor();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }
    }
}
