﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne.FolderPenColor
{
    /// <summary>
    /// Логика взаимодействия для addPenColor.xaml
    /// </summary>
    public partial class addPenColor : Page
    {
        public addPenColor()
        {
            InitializeComponent();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            color_pen _pen_color = new color_pen();
            _pen_color.pen_color_title = fioView.Text;
            DatabaseControl.AddPenColor(new color_pen
            {
                pen_color_title= fioView.Text
            });
            daf.Content = new penColor();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void fioView_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Return)
            {
                color_pen _pen_color = new color_pen();
                _pen_color.pen_color_title = fioView.Text;
                DatabaseControl.AddPenColor(new color_pen
                {
                    pen_color_title = fioView.Text
                });
                daf.Content = new penColor();
            }
        }
    }
}
