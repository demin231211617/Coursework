﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewFolder1;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addDoorColor.xaml
    /// </summary>
    public partial class addDoorColor : Page
    {
        public addDoorColor()
        {
            InitializeComponent();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            door_color _door_color = new door_color();
            _door_color.door_color_title = fioView.Text;
            DatabaseControl.AddDoorColor(new door_color
            {
                door_color_title = fioView.Text
            });
            daf.Content = new DoorColor();
        }

        private void fioView_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Return)
            {
                door_color _door_color = new door_color();
                _door_color.door_color_title = fioView.Text;
                DatabaseControl.AddDoorColor(new door_color
                {
                    door_color_title = fioView.Text
                });
                daf.Content = new DoorColor();
            }
        }
    }
}
