﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.FolderPenColor;

namespace thisNumberOne.FolderGlassColor
{
    /// <summary>
    /// Логика взаимодействия для addGlassColor.xaml
    /// </summary>
    public partial class addGlassColor : Page
    {
        public addGlassColor()
        {
            InitializeComponent();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            glass_color _glass_color = new glass_color();
            _glass_color.glass_color_title = fioView.Text;
            DatabaseControl.AddGlassColor(new glass_color
            {
                glass_color_title = fioView.Text
            });
            daf.Content = new glassColor();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void fioView_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Return)
            {
                glass_color _glass_color = new glass_color();
                _glass_color.glass_color_title = fioView.Text;
                DatabaseControl.AddGlassColor(new glass_color
                {
                    glass_color_title = fioView.Text
                });
                daf.Content = new glassColor();
            }
        }
    }
}
