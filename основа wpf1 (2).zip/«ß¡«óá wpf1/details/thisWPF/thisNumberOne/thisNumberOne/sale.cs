﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using thisNumberOne.NewDoor;

namespace thisNumberOne
{
    public class sale
    {
        [Key]public int sale_id { get; set; }
        public int sale_cost { get; set; }
        [ForeignKey("clientEntity")]public int buyer { get; set; }
        [ForeignKey("doorEntity")]public int sale_door { get; set; }
        [ForeignKey("penEntity")]public int sale_pen { get; set; }
        [ForeignKey("employeeEntity")]public int saller { get; set; }               
        [ForeignKey("paymentEntity")]public int sale_payment { get; set; }
        public client clientEntity { get; set; }
        public door doorEntity { get; set; }
        public pen penEntity { get; set; }
        public employee_db employeeEntity { get; set; }
        public payment paymentEntity { get; set; }

    }
}
