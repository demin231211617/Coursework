﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для User.xaml
    /// </summary>
    public partial class User : Page
    {
        public User()
        {
            InitializeComponent();
            UserClient.ItemsSource = DatabaseControl.GetPhonesForView();
        }
        public void RefreshTable()
        {
            UserClient.ItemsSource = null;
            UserClient.ItemsSource = DatabaseControl.GetPhonesForView();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            fas.Content = new addAnClient();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            client p = UserClient.SelectedItem as client;
            if(p != null)
            {
                fas.Content = new editAnClient(p);
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            client p = UserClient.SelectedItem as client;
            if (p != null)
            {
                DatabaseControl.DelClient(UserClient.SelectedItem as client);
                UserClient.ItemsSource = null;
                UserClient.ItemsSource = DatabaseControl.GetPhonesForView();
            }
            else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
